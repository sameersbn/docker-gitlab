Haml::Template.options[:ugly] = true
